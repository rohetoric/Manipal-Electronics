/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecommercetrial1;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
public class   Ecommercetrial1 extends JFrame{
/*
 Ecommercetrial1()
 {
  /*   
  JTextField textField = new JTextField();
  
  textField.setColumns(20);
  textField.setEditable(false);
  textField.setFont(new java.awt.Font("Arial", Font.BOLD | Font.BOLD, 12));
  textField.setForeground(Color.BLUE);
  textField.setBackground(Color.YELLOW);
  textField.setHorizontalAlignment(JTextField.CENTER);
  textField.setText("Welcome to E-Commerce Website");
  add(textField);

  
  JButton bt1 = new JButton("Login");		//Creating a Login Button.
  JButton bt2 = new JButton("Signup");	        //Creating a Signup Button.
  
  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //setting close operation.
  setLayout(new FlowLayout());		//setting layout using FlowLayout object
  setSize(400, 400);			//setting size of Jframe
  
  add(bt1);		//adding Yes button to frame.
  add(bt2);		//adding No button to frame.
  
  setVisible(true);
  
  
 }
/*
/**
 *
 * @author student
 */
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    new Ecommercetrial1();
    }
    
}
